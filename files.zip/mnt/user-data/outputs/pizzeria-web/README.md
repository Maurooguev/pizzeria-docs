# pizzeria-web

Panel web de reportes y gestión para pizzería. Construido en React.

## Stack
- React 18
- React Router (navegación)
- Recharts (gráficos)
- Axios (llamadas a la API)
- TailwindCSS (estilos)

## Estructura del proyecto

```
pizzeria-web/
├── src/
│   ├── main.jsx
│   ├── App.jsx
│   ├── api/
│   │   ├── axiosClient.js       # Instancia Axios con JWT
│   │   ├── reportes.js
│   │   ├── productos.js
│   │   └── pedidos.js
│   ├── components/
│   │   ├── Navbar.jsx
│   │   ├── DateRangePicker.jsx
│   │   ├── TablaVentas.jsx
│   │   ├── GraficoBarras.jsx
│   │   └── GraficoTorta.jsx
│   ├── pages/
│   │   ├── Login.jsx
│   │   ├── Ventas.jsx           # Pestaña ventas
│   │   ├── Cancelaciones.jsx    # Pestaña cancelaciones
│   │   ├── Productos.jsx        # Pestaña productos (ranking + ABM)
│   │   └── NotFound.jsx
│   └── context/
│       └── AuthContext.jsx      # JWT y estado de sesión
├── public/
├── index.html
├── package.json
├── tailwind.config.js
└── README.md
```

## Páginas

| Página | Descripción |
|---|---|
| Login | Acceso con usuario y contraseña |
| Ventas | Gráficos + tablas de ventas por período |
| Cancelaciones | Listado de pedidos cancelados con motivo |
| Productos | Ranking de productos + ABM catálogo |

## Cómo levantar el proyecto

```bash
# Clonar el repo
git clone https://github.com/tu-usuario/pizzeria-web.git
cd pizzeria-web

# Instalar dependencias
npm install

# Configurar variables de entorno
cp .env.example .env
# Editar .env con la URL del backend

# Levantar en modo desarrollo
npm run dev
```

El panel queda disponible en `http://localhost:5173`

## Deploy

Se despliega en **Vercel** (gratuito). Conectar el repo de GitHub a Vercel y configurar la variable `VITE_API_URL` con la URL del backend en producción.
