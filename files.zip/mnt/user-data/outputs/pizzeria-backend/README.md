# pizzeria-backend

API REST del sistema POS para pizzería. Construida con FastAPI (Python).

## Stack
- Python 3.11+
- FastAPI
- SQLAlchemy (ORM)
- Alembic (migraciones)
- PostgreSQL (Supabase)
- JWT para autenticación

## Estructura del proyecto

```
pizzeria-backend/
├── app/
│   ├── main.py                  # Entry point
│   ├── config.py                # Variables de entorno
│   ├── database.py              # Conexión a PostgreSQL
│   ├── auth/
│   │   ├── router.py            # POST /auth/login
│   │   ├── schemas.py
│   │   └── utils.py             # JWT helpers
│   ├── productos/
│   │   ├── router.py            # CRUD productos
│   │   ├── models.py
│   │   └── schemas.py
│   ├── categorias/
│   │   ├── router.py
│   │   ├── models.py
│   │   └── schemas.py
│   ├── combos/
│   │   ├── router.py
│   │   ├── models.py
│   │   └── schemas.py
│   ├── pedidos/
│   │   ├── router.py            # CRUD pedidos + cobro
│   │   ├── models.py
│   │   └── schemas.py
│   ├── reportes/
│   │   ├── router.py            # Ventas, rankings, comparaciones
│   │   └── queries.py
│   └── storage/
│       └── utils.py             # Upload imágenes a Supabase Storage
├── alembic/
│   └── versions/                # Migraciones SQL
├── tests/
├── .env.example
├── requirements.txt
└── README.md
```

## Endpoints principales

| Método | Ruta | Descripción |
|---|---|---|
| POST | /auth/login | Login, devuelve JWT |
| GET | /productos | Listar productos activos |
| POST | /productos | Crear producto |
| PUT | /productos/{id} | Editar producto |
| DELETE | /productos/{id} | Eliminar o desactivar |
| GET | /categorias | Listar categorías |
| GET | /combos | Listar combos activos |
| POST | /pedidos | Crear pedido |
| PUT | /pedidos/{id}/cobrar | Cerrar y cobrar pedido |
| PUT | /pedidos/{id}/cancelar | Cancelar con motivo |
| GET | /pedidos | Historial con filtros |
| GET | /reportes/ventas | Ventas por período |
| GET | /reportes/productos | Ranking de productos |
| POST | /sync | Sincronizar pedidos offline |

## Cómo levantar el proyecto

```bash
# Clonar el repo
git clone https://github.com/tu-usuario/pizzeria-backend.git
cd pizzeria-backend

# Crear entorno virtual
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate

# Instalar dependencias
pip install -r requirements.txt

# Configurar variables de entorno
cp .env.example .env
# Editar .env con tu URL de Supabase y secret JWT

# Correr migraciones
alembic upgrade head

# Levantar el servidor
uvicorn app.main:app --reload
```

La API queda disponible en `http://localhost:8000`  
Documentación automática en `http://localhost:8000/docs`
