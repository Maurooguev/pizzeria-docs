# pizzeria-app

App Android de punto de venta (POS) para pizzería. Construida en Kotlin.

## Stack
- Kotlin
- Android mínimo API 26 (Android 8.0)
- Jetpack Compose (UI)
- Retrofit (llamadas a la API)
- Room (base de datos local SQLite para modo offline)
- DataStore (preferencias y token JWT)
- Hilt (inyección de dependencias)

## Estructura del proyecto

```
pizzeria-app/
├── app/
│   └── src/
│       └── main/
│           ├── java/com/pizzeria/pos/
│           │   ├── MainActivity.kt
│           │   ├── di/                      # Hilt modules
│           │   ├── data/
│           │   │   ├── api/                 # Retrofit interfaces
│           │   │   │   ├── ApiService.kt
│           │   │   │   └── models/          # DTOs de la API
│           │   │   ├── local/               # Room database
│           │   │   │   ├── AppDatabase.kt
│           │   │   │   ├── dao/
│           │   │   │   └── entities/        # Entidades SQLite
│           │   │   └── repository/          # Une API + local
│           │   ├── domain/
│           │   │   ├── models/              # Modelos del negocio
│           │   │   └── usecases/            # Lógica de negocio
│           │   └── ui/
│           │       ├── theme/               # Colores, tipografía
│           │       ├── components/          # Componentes reutilizables
│           │       ├── carta/               # Pantalla principal POS
│           │       ├── pedido/              # Detalle del pedido
│           │       ├── cobro/               # Pantalla de cobro
│           │       ├── historial/           # Historial de pedidos
│           │       ├── configuracion/       # ABM productos (solo dueño)
│           │       └── reportes/            # Reporte del día (empleado)
│           └── res/
│               ├── layout/
│               ├── drawable/
│               └── values/
├── build.gradle
└── README.md
```

## Pantallas principales

| Pantalla | Descripción |
|---|---|
| Carta | Grilla de productos + panel lateral del pedido |
| Detalle producto | Modificadores, media pizza, selector de sabores |
| Cobro | Datos delivery, método de pago, confirmar |
| Historial | Lista de pedidos con filtro por fecha |
| Reporte del día | Resumen de ventas (empleado) |
| Configuración | ABM productos, combos, categorías (dueño) |

## Cómo configurar el proyecto

1. Instalar **Android Studio** (versión Hedgehog o superior)
2. Clonar el repo:
```bash
git clone https://github.com/tu-usuario/pizzeria-app.git
```
3. Abrir la carpeta en Android Studio
4. Crear el archivo `local.properties` en la raíz y agregar:
```
BASE_URL=http://tu-backend.com/
```
5. Sync Gradle y correr en la tablet o emulador
